from django.views import View
from django.shortcuts import render,HttpResponse
from shop.models.customer import Customer


class User(View):

    def post(self,request):
        customer = request.session.get('customer')
        first_name=request.session.get('first_name')

        
        return render(request,'user.html',{'first_name':first_name})

