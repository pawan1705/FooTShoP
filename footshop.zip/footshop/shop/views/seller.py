from django.views import View
from django.shortcuts import render


def seller(request):
        return render(request,'seller.html')

def meetme(request):
        return render(request,'meetme.html')