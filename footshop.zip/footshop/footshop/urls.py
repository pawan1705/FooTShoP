from shop.views import home,login,signup
from shop.views.login import logout
from shop.views.cart import Cart
from shop.views.checkout import CheckOut
from shop.views.orders import OrderView
from shop.middlewares.auth import auth_middleware
from shop.views.seller import seller,meetme
from shop.views.user import User
from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from . import settings


urlpatterns = [
    path('admin/', admin.site.urls),
path('',home.Index.as_view(), name="homepage"),
    path('signup',signup.Signup.as_view(), name='signup'),
    path('login',login.Login.as_view(), name='login'),
    path('logout',logout,name ='logout'),
    path('cart', Cart.as_view(),name='cart'),
    path('check-out', CheckOut.as_view(),name='checkout'),
    path('orders',auth_middleware(OrderView.as_view()), name='orders'),
    path('seller',seller,name='seller'),
    path('meetme', meetme, name='meetme'),
    path('user',User.as_view(),name='user'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)